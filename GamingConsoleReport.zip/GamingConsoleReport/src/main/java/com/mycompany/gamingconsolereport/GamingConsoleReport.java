/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

   
    public static void main(String[] args) {
         int [] [] 
        yearlySales = {
     {1000 ,2000, 3000} ;
                
     {2000, 3000, 4000};
     
     {1500, 1100, 1200}; 
     
    };
             
           
    }
    
        for (int row = 0; row < yearlySales.length; row++ ){
           for (int col = 0; col < yearlySales[row].length; col++){
              System.out.print(yearlySales[row] [col] + " ");
}
    System.out.println();
}
        for (int row = o; row < yearlySales.length; row++){
        int total = 0;
        for (int col = 0; col < yearlySales[row].length; col++){
        total += yearlySales [row] [col];
                }
        System.out.println("Total sales "+(row + 1)+ " " + total);
}

    
    
    
        
    

