/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapplication;

/**
 *
 * @author Student
 */
public class XBOX extends AbstractConsoles  {
    
  boolean totalSales;
     
     XBOX(){
    
    totalSales = true;
     }
     public void printDtailsOne(){
         System.out.println("The device name :" + XBOX);
     
     }
    
}
