/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapplication;

/**
 *
 * @author Student
 */
public class SWITCH extends AbstractConsoles  { 
    
    boolean totalSales;
     
  SWITCH(){
    
    totalSales = true;
     }
  public void printDtailsTwo(){
         System.out.println("The device name :" + SWITCH);
     
     }
    
}
