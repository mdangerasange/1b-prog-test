/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapplication;

/**
 *
 * @author Student
 */
public class AbstractConsoles {
    
    String PS5;
    String XBOX;
    String SWITCH;
    String NumberOneElEctronicStore;
    int totalSales;
    
  
    public void deviceType( String PS5 , String XBOX , String SWITCH){
      this.PS5 = PS5;
      this. XBOX = XBOX;
      this.SWITCH = SWITCH ;
    }
    
    public void storeName(String NumberOneElEctronicStore){
        this.NumberOneElEctronicStore = NumberOneElEctronicStore;
       
    }
            
    
    
}
