/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapplication;

/**
 *
 * @author Student
 */
public class PS5 extends AbstractConsoles  {

     boolean totalSales;
     
     PS5(){
    
    totalSales = true;
     }
     
     void printDtails(){
         System.out.println("The device name :" + PS5);
     
     }
    
}
