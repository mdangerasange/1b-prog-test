/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consoleapplication;

/**
 *
 * @author Student
 */
public class ConsoleApplication {

    public static void main(String[] args) {
       PS5 PS5 = new PS5("PS5");
       XBOX XBOX = new XBOX();
        System.out.println(XBOX.totalSales );
       
       System.out.println(PS5.totalSales );
    }
    
    PS5.printDtails();
    XBOX. printDtailsOne();
    SWUTCH. printDtailsTwo()
    
}
